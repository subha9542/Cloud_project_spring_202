
mpiexec -n 3 python3 data_retrieve.py

